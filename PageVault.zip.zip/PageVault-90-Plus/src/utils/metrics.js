const BUCKETS_MS = [10, 50, 150, 500, 1500];

const state = {
  requests: new Map(),
  durationCount: 0,
  durationSum: 0,
  durationBuckets: new Array(BUCKETS_MS.length).fill(0),
};

function recordHttpMetric(method, route, statusCode, durationMs) {
  const key = `${method}|${route}|${statusCode}`;
  state.requests.set(key, (state.requests.get(key) || 0) + 1);

  state.durationCount += 1;
  state.durationSum += durationMs;
  for (let i = 0; i < BUCKETS_MS.length; i += 1) {
    if (durationMs <= BUCKETS_MS[i]) {
      state.durationBuckets[i] += 1;
    }
  }
}

function formatPrometheusMetrics(cacheStats = { hits: 0, misses: 0, size: 0 }) {
  const lines = [
    "# HELP pagevault_http_requests_total Total HTTP requests processed",
    "# TYPE pagevault_http_requests_total counter",
  ];

  for (const [key, count] of state.requests.entries()) {
    const [method, route, status] = key.split("|");
    lines.push(
      `pagevault_http_requests_total{method="${method}",route="${route}",status="${status}"} ${count}`
    );
  }

  lines.push(
    "# HELP pagevault_http_request_duration_ms HTTP request duration histogram in ms",
    "# TYPE pagevault_http_request_duration_ms histogram"
  );
  for (let i = 0; i < BUCKETS_MS.length; i += 1) {
    lines.push(`pagevault_http_request_duration_ms_bucket{le="${BUCKETS_MS[i]}"} ${state.durationBuckets[i]}`);
  }
  lines.push(`pagevault_http_request_duration_ms_bucket{le="+Inf"} ${state.durationCount}`);
  lines.push(`pagevault_http_request_duration_ms_sum ${state.durationSum.toFixed(2)}`);
  lines.push(`pagevault_http_request_duration_ms_count ${state.durationCount}`);

  lines.push(
    "# HELP pagevault_openlibrary_cache_hits_total Open Library cache hits",
    "# TYPE pagevault_openlibrary_cache_hits_total counter",
    `pagevault_openlibrary_cache_hits_total ${cacheStats.hits}`,
    "# HELP pagevault_openlibrary_cache_misses_total Open Library cache misses",
    "# TYPE pagevault_openlibrary_cache_misses_total counter",
    `pagevault_openlibrary_cache_misses_total ${cacheStats.misses}`,
    "# HELP pagevault_openlibrary_cache_entries Current entries in Open Library cache",
    "# TYPE pagevault_openlibrary_cache_entries gauge",
    `pagevault_openlibrary_cache_entries ${cacheStats.size}`,
    "# HELP pagevault_process_uptime_seconds Process uptime in seconds",
    "# TYPE pagevault_process_uptime_seconds gauge",
    `pagevault_process_uptime_seconds ${process.uptime().toFixed(2)}`,
    "# HELP pagevault_process_memory_rss_bytes Resident set size in bytes",
    "# TYPE pagevault_process_memory_rss_bytes gauge",
    `pagevault_process_memory_rss_bytes ${process.memoryUsage().rss}`
  );

  return `${lines.join("\n")}\n`;
}

module.exports = { recordHttpMetric, formatPrometheusMetrics };
