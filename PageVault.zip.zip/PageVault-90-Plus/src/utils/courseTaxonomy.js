const DEPARTMENTS = Object.freeze({
  CS: "Computer Science & Engineering",
  AI: "Artificial Intelligence & Machine Learning",
  ML: "Machine Learning",
  DS: "Data Science",
  EC: "Electronics & Communication",
  EE: "Electrical Engineering",
  ME: "Mechanical Engineering",
  CE: "Civil Engineering",
  MA: "Mathematics",
  PH: "Physics",
  HS: "Humanities & Social Sciences",
  MBA: "Management & Business",
});

const COURSE_PATTERN = /^([A-Z]{2,3})[-\s]?([1-8]\d{2})$/;

function parseCourseCode(raw) {
  if (typeof raw !== "string") return null;
  const cleaned = raw.trim().toUpperCase();
  if (!cleaned) return null;

  const match = COURSE_PATTERN.exec(cleaned);
  if (!match) return null;

  const [, dept, numberStr] = match;
  if (!Object.prototype.hasOwnProperty.call(DEPARTMENTS, dept)) {
    return null;
  }

  const level = Number(numberStr);
  return {
    code: `${dept}${numberStr}`,
    department: dept,
    departmentName: DEPARTMENTS[dept],
    level: Math.floor(level / 100) * 100,
    number: level,
  };
}

function isValidCourseCode(raw) {
  return parseCourseCode(raw) !== null;
}

function normalizeCourseCode(raw) {
  const parsed = parseCourseCode(raw);
  return parsed ? parsed.code : null;
}

function listDepartments() {
  return Object.entries(DEPARTMENTS).map(([code, name]) => ({ code, name }));
}

module.exports = {
  DEPARTMENTS,
  parseCourseCode,
  isValidCourseCode,
  normalizeCourseCode,
  listDepartments,
};
