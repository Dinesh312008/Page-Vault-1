const db = require("../db/database");
const { parseCourseCode } = require("../utils/courseTaxonomy");

const STOP_WORDS = new Set([
  "the", "and", "for", "with", "that", "this", "from", "into", "your", "about",
  "book", "edition", "guide", "introduction", "to", "of", "in", "on", "a", "an",
]);

function tokenize(text) {
  if (!text) return [];
  return String(text)
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((tok) => tok.length >= 2 && !STOP_WORDS.has(tok));
}

function buildDocumentText(book) {
  return [book.title, book.author, book.description, book.courseCode || book.course_code]
    .filter(Boolean)
    .join(" ");
}

function scoreBm25(queryTokens, corpus, k1 = 1.5, b = 0.75) {
  const N = corpus.length;
  if (N === 0 || queryTokens.length === 0) return new Map();

  const tokenizedDocs = corpus.map((doc) => tokenize(buildDocumentText(doc)));
  const avgDl = tokenizedDocs.reduce((acc, d) => acc + d.length, 0) / N || 1;

  const docFreq = new Map();
  for (const tokens of tokenizedDocs) {
    const unique = new Set(tokens);
    for (const term of unique) {
      docFreq.set(term, (docFreq.get(term) || 0) + 1);
    }
  }

  const scores = new Map();
  for (let i = 0; i < N; i += 1) {
    const tokens = tokenizedDocs[i];
    const dl = tokens.length || 1;
    const tfMap = new Map();
    for (const t of tokens) tfMap.set(t, (tfMap.get(t) || 0) + 1);

    let score = 0;
    for (const q of queryTokens) {
      const tf = tfMap.get(q) || 0;
      if (tf === 0) continue;
      const df = docFreq.get(q) || 0;
      const idf = Math.log((N - df + 0.5) / (df + 0.5) + 1);
      const norm = tf + k1 * (1 - b + (b * dl) / avgDl);
      score += idf * ((tf * (k1 + 1)) / norm);
    }
    scores.set(corpus[i].id, score);
  }
  return scores;
}

function rankBooks(books, { queryText = "", preferredDepartments = [], excludeOwnerId = null, limit = 5 } = {}) {
  const candidates = books.filter(
    (b) => b.status === "available" && (excludeOwnerId === null || b.ownerId !== excludeOwnerId)
  );
  if (candidates.length === 0) return [];

  const queryTokens = tokenize(queryText);
  const bm25Scores = scoreBm25(queryTokens, candidates);
  const deptSet = new Set(preferredDepartments.map((d) => String(d).toUpperCase()));

  const ranked = candidates.map((book) => {
    const textScore = bm25Scores.get(book.id) || 0;
    const parsedCourse = parseCourseCode(book.courseCode || book.course_code || "");
    const deptBoost = parsedCourse && deptSet.has(parsedCourse.department) ? 1.75 : 0;
    const totalScore = Number((textScore + deptBoost).toFixed(4));
    return { ...book, relevanceScore: totalScore };
  });

  ranked.sort((a, b) => b.relevanceScore - a.relevanceScore || b.id - a.id);
  return ranked.slice(0, Math.max(1, Math.min(limit, 20)));
}

function recommendForUser(userId, { query = "", courseCode = "", limit = 5 } = {}) {
  const allBooks = db.prepare(`
    SELECT b.id, b.title, b.author, b.isbn, b.description, b.cover_url AS coverUrl,
           b.course_code AS courseCode, b.status, b.owner_id AS ownerId, u.name AS ownerName
    FROM books b JOIN users u ON u.id = b.owner_id
  `).all();

  const history = userId
    ? db.prepare(`
        SELECT b.title, b.author, b.description, b.course_code AS courseCode
        FROM borrow_requests r JOIN books b ON b.id = r.book_id
        WHERE r.requester_id = ?
        ORDER BY r.requested_at DESC LIMIT 10
      `).all(userId)
    : [];

  const historyText = history.map(buildDocumentText).join(" ");
  const combinedQuery = [query, courseCode, historyText].filter(Boolean).join(" ");

  const preferredDepts = [];
  const requestedCourse = parseCourseCode(courseCode);
  if (requestedCourse) preferredDepts.push(requestedCourse.department);
  for (const item of history) {
    const parsed = parseCourseCode(item.courseCode || "");
    if (parsed) preferredDepts.push(parsed.department);
  }

  return rankBooks(allBooks, {
    queryText: combinedQuery,
    preferredDepartments: preferredDepts,
    excludeOwnerId: userId || null,
    limit,
  });
}

module.exports = { tokenize, scoreBm25, rankBooks, recommendForUser };
