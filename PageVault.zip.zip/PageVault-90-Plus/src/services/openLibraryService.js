const logger = require("../config/logger");
const { TtlCache } = require("../utils/apiCache");

const searchCache = new TtlCache({ ttlMs: 15 * 60 * 1000, maxEntries: 200 });

async function searchOpenLibrary(query, limit = 10, { cache = searchCache, fetcher = fetch } = {}) {
  const clampedLimit = Math.min(Math.max(limit, 1), 20);
  const cacheKey = `${String(query).trim().toLowerCase()}|${clampedLimit}`;
  const cached = cache.get(cacheKey);
  if (cached !== undefined) {
    return cached;
  }

  const url = new URL("https://openlibrary.org/search.json");
  url.searchParams.set("q", query);
  url.searchParams.set("limit", String(clampedLimit));
  url.searchParams.set("fields", "key,title,author_name,first_publish_year,isbn,cover_i");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetcher(url, {
      signal: controller.signal,
      headers: { "User-Agent": "PageVault-OpenShelf/2.2 (student project)" },
    });
    if (!response.ok) throw new Error(`Open Library returned HTTP ${response.status}`);
    const data = await response.json();
    const mapped = (data.docs || []).map((book) => ({
      externalId: book.key,
      title: book.title || "Untitled",
      author: (book.author_name || ["Unknown author"])[0],
      year: book.first_publish_year || null,
      isbn: (book.isbn || [])[0] || null,
      coverUrl: book.cover_i ? `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg` : null,
    }));
    cache.set(cacheKey, mapped);
    return mapped;
  } catch (error) {
    logger.warn("Open Library search failed", { message: error.message });
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

function getCacheStats() {
  return searchCache.stats();
}

module.exports = { searchOpenLibrary, getCacheStats };
