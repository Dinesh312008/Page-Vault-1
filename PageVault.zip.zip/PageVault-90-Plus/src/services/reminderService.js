const db = require("../db/database");
function notifyOverdue() {
  // Borrow records older than 14 days are flagged for a reminder. A reminder is
  // inserted only once per user/book/day to prevent repeated cron notifications.
  const overdue = db.prepare(`
    SELECT r.id,r.requester_id,r.book_id,b.title
    FROM borrow_requests r JOIN books b ON b.id=r.book_id
    WHERE r.status='approved'
      AND datetime(r.decided_at) < datetime('now','-14 days')
      AND NOT EXISTS (
        SELECT 1 FROM notifications n
        WHERE n.user_id=r.requester_id
          AND n.message LIKE '%' || b.title || '%overdue reminder%'
          AND date(n.created_at)=date('now')
      )
  `).all();
  const insert = db.prepare("INSERT INTO notifications(user_id,message) VALUES(?,?)");
  const tx = db.transaction((items) => {
    for (const item of items) insert.run(item.requester_id, `Overdue reminder: "${item.title}" is overdue. Please return it.`);
  });
  tx(overdue);
  return overdue.length;
}
module.exports = { notifyOverdue };
