const bcrypt = require("bcryptjs");
const db = require("../db/database");

async function register({ name, email, password }) {
  const exists = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
  if (exists) {
    const error = new Error("An account with this email already exists.");
    error.status = 409;
    throw error;
  }
  const passwordHash = await bcrypt.hash(password, 12);
  const result = db.prepare(
    "INSERT INTO users (name,email,password_hash) VALUES (?,?,?)"
  ).run(name, email, passwordHash);
  return db.prepare("SELECT id,name,email,role FROM users WHERE id = ?").get(result.lastInsertRowid);
}
async function login({ email, password }) {
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  const valid = user ? await bcrypt.compare(password, user.password_hash) : false;
  if (!valid) {
    const error = new Error("Invalid email or password.");
    error.status = 401;
    throw error;
  }
  return { id: user.id, name: user.name, email: user.email, role: user.role };
}
module.exports = { register, login };
