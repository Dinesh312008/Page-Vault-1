const db = require("../db/database");

function requestBook(bookId, requesterId) {
  const create = db.transaction(() => {
    const book = db.prepare("SELECT * FROM books WHERE id=?").get(bookId);
    if (!book) { const e = new Error("Book not found."); e.status = 404; throw e; }
    if (book.owner_id === requesterId) {
      const e = new Error("You cannot request your own book."); e.status = 400; throw e;
    }
    if (book.status !== "available") {
      const e = new Error("This book is not currently available."); e.status = 409; throw e;
    }
    const existing = db.prepare(
      "SELECT id FROM borrow_requests WHERE book_id=? AND requester_id=? AND status='pending'"
    ).get(bookId, requesterId);
    if (existing) { const e = new Error("You already have a pending request."); e.status = 409; throw e; }
    const result = db.prepare(
      "INSERT INTO borrow_requests(book_id,requester_id) VALUES(?,?)"
    ).run(bookId, requesterId);
    db.prepare("UPDATE books SET status='requested',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(bookId);
    db.prepare("INSERT INTO notifications(user_id,message) VALUES(?,?)")
      .run(book.owner_id, `A student requested "${book.title}".`);
    return { id: result.lastInsertRowid, bookId, status: "pending" };
  });
  return create.immediate();
}

function decideRequest(requestId, ownerId, decision) {
  const decide = db.transaction(() => {
    const request = db.prepare(`
      SELECT r.*,b.owner_id,b.title,b.status AS book_status
      FROM borrow_requests r JOIN books b ON b.id=r.book_id WHERE r.id=?
    `).get(requestId);
    if (!request) { const e = new Error("Request not found."); e.status = 404; throw e; }
    if (request.owner_id !== ownerId) { const e = new Error("Only the book owner can decide this request."); e.status = 403; throw e; }
    if (request.status !== "pending" || request.book_status !== "requested") {
      const e = new Error("This request has already been processed."); e.status = 409; throw e;
    }
    if (decision === "approved") {
      db.prepare("UPDATE borrow_requests SET status='rejected',decided_at=CURRENT_TIMESTAMP WHERE book_id=? AND id<>? AND status='pending'")
        .run(request.book_id, requestId);
      db.prepare("UPDATE books SET status='borrowed',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='requested'")
        .run(request.book_id);
    } else {
      db.prepare("UPDATE books SET status='available',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='requested'")
        .run(request.book_id);
    }
    db.prepare("UPDATE borrow_requests SET status=?,decided_at=CURRENT_TIMESTAMP WHERE id=? AND status='pending'")
      .run(decision, requestId);
    db.prepare("INSERT INTO notifications(user_id,message) VALUES(?,?)")
      .run(request.requester_id, `Your request for "${request.title}" was ${decision}.`);
    return { id: requestId, status: decision };
  });
  return decide.immediate();
}

function returnBook(requestId, requesterId) {
  const giveBack = db.transaction(() => {
    const request = db.prepare(`
      SELECT r.*,b.title,b.owner_id FROM borrow_requests r
      JOIN books b ON b.id=r.book_id WHERE r.id=?
    `).get(requestId);
    if (!request) { const e = new Error("Borrow record not found."); e.status = 404; throw e; }
    if (request.requester_id !== requesterId) { const e = new Error("Only the borrower can mark this book returned."); e.status = 403; throw e; }
    if (request.status !== "approved") { const e = new Error("Only an approved borrow can be returned."); e.status = 409; throw e; }
    db.prepare("UPDATE borrow_requests SET status='returned',decided_at=CURRENT_TIMESTAMP WHERE id=? AND status='approved'").run(requestId);
    db.prepare("UPDATE books SET status='available',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='borrowed'").run(request.book_id);
    db.prepare("INSERT INTO notifications(user_id,message) VALUES(?,?)")
      .run(request.owner_id, ` "${request.title}" has been marked as returned.`);
    return { id: requestId, status: "returned" };
  });
  return giveBack.immediate();
}
module.exports = { requestBook, decideRequest, returnBook };
