const db = require("../db/database");
const { normalizeCourseCode } = require("../utils/courseTaxonomy");

function listBooks({ page, limit, search, status, courseCode }) {
  const conditions = [];
  const params = [];
  if (search) {
    conditions.push("(b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ? OR b.course_code LIKE ?)");
    const term = `%${search}%`;
    params.push(term, term, term, term);
  }
  if (status) {
    conditions.push("b.status = ?");
    params.push(status);
  }
  if (courseCode) {
    const normalized = normalizeCourseCode(courseCode) || courseCode.trim().toUpperCase();
    conditions.push("b.course_code = ?");
    params.push(normalized);
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  const total = db.prepare(`SELECT COUNT(*) AS count FROM books b ${where}`).get(...params).count;
  const rows = db.prepare(`
    SELECT b.id,b.title,b.author,b.isbn,b.course_code AS courseCode,b.description,b.cover_url AS coverUrl,
           b.status,b.owner_id AS ownerId,u.name AS ownerName,b.created_at AS createdAt
    FROM books b JOIN users u ON u.id=b.owner_id
    ${where} ORDER BY b.created_at DESC LIMIT ? OFFSET ?
  `).all(...params, limit, (page - 1) * limit);
  return { data: rows, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } };
}

function addBook(ownerId, input) {
  const normalizedCourse = input.courseCode ? normalizeCourseCode(input.courseCode) : null;
  const result = db.prepare(`
    INSERT INTO books(owner_id,title,author,isbn,course_code,description,cover_url)
    VALUES(@ownerId,@title,@author,@isbn,@courseCode,@description,@coverUrl)
  `).run({
    ownerId,
    title: input.title,
    author: input.author,
    isbn: input.isbn || "",
    courseCode: normalizedCourse,
    description: input.description || "",
    coverUrl: input.coverUrl || null,
  });
  return db.prepare("SELECT * FROM books WHERE id=?").get(result.lastInsertRowid);
}

module.exports = { listBooks, addBook };
