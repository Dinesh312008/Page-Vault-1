const { z } = require("zod");
require("dotenv").config();

const schema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  PORT: z.coerce.number().int().min(1).max(65535).default(3000),
  SESSION_SECRET: z.string().min(32, "SESSION_SECRET must contain at least 32 characters"),
  SESSION_NAME: z.string().min(1).default("pagevault.sid"),
  DATABASE_PATH: z.string().default("./data/pagevault.sqlite"),
  SESSION_DB_PATH: z.string().default("./data/sessions.sqlite"),
  LOG_LEVEL: z.enum(["error", "warn", "info", "http", "verbose", "debug", "silly"]).default("info"),
  APP_BASE_URL: z.string().url().default("http://localhost:3000")
});

const parsed = schema.safeParse(process.env);
if (!parsed.success) {
  console.error("Invalid environment configuration:");
  console.error(parsed.error.flatten().fieldErrors);
  process.exit(1);
}
if (parsed.data.NODE_ENV === "production" &&
    parsed.data.SESSION_SECRET.toLowerCase().includes("replace-this")) {
  console.error("A real SESSION_SECRET is required in production.");
  process.exit(1);
}
module.exports = Object.freeze(parsed.data);
