const winston = require("winston");
const config = require("./env");

require("node:fs").mkdirSync("logs", { recursive: true });

const logger = winston.createLogger({
  level: config.LOG_LEVEL,
  defaultMeta: { service: "pagevault-api" },
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console({
      format: config.NODE_ENV === "development"
        ? winston.format.combine(winston.format.colorize(), winston.format.simple())
        : winston.format.json()
    }),
    ...(config.NODE_ENV === "test" ? [] : [
      new winston.transports.File({ filename: "logs/error.log", level: "error" }),
      new winston.transports.File({ filename: "logs/combined.log" })
    ])
  ],
  exitOnError: false
});
module.exports = logger;
