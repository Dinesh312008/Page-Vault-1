const crypto = require("node:crypto");

const SAFE_METHODS = new Set(["GET", "HEAD", "OPTIONS"]);

function ensureCsrfToken(session) {
  if (!session.csrfToken) {
    session.csrfToken = crypto.randomBytes(32).toString("hex");
  }
  return session.csrfToken;
}

function timingSafeEquals(a, b) {
  if (typeof a !== "string" || typeof b !== "string") return false;
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

function csrfProtection(req, res, next) {
  if (SAFE_METHODS.has(req.method)) {
    if (req.session) ensureCsrfToken(req.session);
    return next();
  }

  // Allow unauthenticated login/register to establish a new session
  if (req.path === "/api/auth/login" || req.path === "/api/auth/register") {
    return next();
  }

  if (!req.session || !req.session.user) {
    return next();
  }

  const expected = req.session.csrfToken;
  const provided = req.get("x-csrf-token") || (req.body && req.body._csrf);

  if (!expected || !timingSafeEquals(String(provided || ""), expected)) {
    return res.status(403).json({ error: "Invalid or missing CSRF token." });
  }
  return next();
}

module.exports = { ensureCsrfToken, csrfProtection };
