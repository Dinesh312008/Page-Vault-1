const logger = require("../config/logger");
function notFound(req, res) {
  res.status(404).json({ error: "Route not found." });
}
function errorHandler(err, req, res, next) {
  logger.error("Request failed", {
    message: err.message,
    stack: err.stack,
    method: req.method,
    path: req.originalUrl,
    requestId: req.id
  });
  if (res.headersSent) return next(err);
  const status = Number.isInteger(err.status) ? err.status : 500;
  res.status(status).json({
    error: status >= 500 ? "An unexpected server error occurred." : err.message,
    ...(process.env.NODE_ENV === "development" ? { details: err.message } : {})
  });
}
module.exports = { notFound, errorHandler };
