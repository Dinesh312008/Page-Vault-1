const express = require("express");
const { requireAuth } = require("../middleware/auth");
const db = require("../db/database");
const router = express.Router();
router.use(requireAuth);
router.get("/", (req,res) => {
  const data = db.prepare("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50").all(req.session.user.id);
  res.json({ data });
});
router.patch("/:id/read", (req,res) => {
  const result = db.prepare("UPDATE notifications SET read_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?")
    .run(Number(req.params.id), req.session.user.id);
  if (!result.changes) return res.status(404).json({ error: "Notification not found." });
  res.json({ message: "Notification marked as read." });
});
module.exports = router;
