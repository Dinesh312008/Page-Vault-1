const express = require("express");
const { z } = require("zod");
const { requireAuth } = require("../middleware/auth");
const asyncRoute = require("../utils/asyncRoute");
const borrowService = require("../services/borrowService");
const db = require("../db/database");
const router = express.Router();

router.use(requireAuth);
router.post("/:bookId/request", (req,res) => {
  const id = z.coerce.number().int().positive().parse(req.params.bookId);
  res.status(201).json({ request: borrowService.requestBook(id, req.session.user.id) });
});
router.patch("/:requestId/decision", (req,res) => {
  const id = z.coerce.number().int().positive().parse(req.params.requestId);
  const { decision } = z.object({ decision: z.enum(["approved","rejected"]) }).parse(req.body);
  res.json({ request: borrowService.decideRequest(id, req.session.user.id, decision) });
});
router.patch("/:requestId/return", (req,res) => {
  const id = z.coerce.number().int().positive().parse(req.params.requestId);
  res.json({ request: borrowService.returnBook(id, req.session.user.id) });
});
router.get("/mine", (req,res) => {
  const data = db.prepare(`
    SELECT r.id,r.status,r.requested_at AS requestedAt,r.decided_at AS decidedAt,
           b.id AS bookId,b.title,b.author,b.owner_id AS ownerId,u.name AS ownerName
    FROM borrow_requests r JOIN books b ON b.id=r.book_id
    JOIN users u ON u.id=b.owner_id
    WHERE r.requester_id=? ORDER BY r.requested_at DESC
  `).all(req.session.user.id);
  res.json({ data });
});
router.get("/incoming", (req,res) => {
  const data = db.prepare(`
    SELECT r.id,r.status,r.requested_at AS requestedAt,b.title,b.author,
           u.name AS requesterName,u.email AS requesterEmail
    FROM borrow_requests r JOIN books b ON b.id=r.book_id
    JOIN users u ON u.id=r.requester_id
    WHERE b.owner_id=? ORDER BY r.requested_at DESC
  `).all(req.session.user.id);
  res.json({ data });
});
module.exports = router;
