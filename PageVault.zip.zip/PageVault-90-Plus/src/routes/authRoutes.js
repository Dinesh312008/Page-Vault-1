const express = require("express");
const { z } = require("zod");
const asyncRoute = require("../utils/asyncRoute");
const authService = require("../services/authService");
const { requireAuth } = require("../middleware/auth");
const { ensureCsrfToken } = require("../middleware/csrf");

const router = express.Router();

const registerSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(160).transform((v) => v.toLowerCase()),
  password: z.string().min(8).max(72),
});
const loginSchema = z.object({
  email: z.string().trim().email().transform((v) => v.toLowerCase()),
  password: z.string().min(1).max(72),
});

router.get("/csrf-token", (req, res) => {
  const csrfToken = ensureCsrfToken(req.session);
  res.json({ csrfToken });
});

router.post("/register", asyncRoute(async (req, res) => {
  const input = registerSchema.parse(req.body);
  const user = await authService.register(input);
  req.session.regenerate((err) => {
    if (err) return res.status(500).json({ error: "Could not create session." });
    req.session.user = user;
    const csrfToken = ensureCsrfToken(req.session);
    res.status(201).json({ user, csrfToken });
  });
}));

router.post("/login", asyncRoute(async (req, res) => {
  const user = await authService.login(loginSchema.parse(req.body));
  req.session.regenerate((err) => {
    if (err) return res.status(500).json({ error: "Could not create session." });
    req.session.user = user;
    const csrfToken = ensureCsrfToken(req.session);
    res.json({ user, csrfToken });
  });
}));

router.post("/logout", requireAuth, (req, res, next) => {
  req.session.destroy((err) => {
    if (err) return next(err);
    res.clearCookie(process.env.SESSION_NAME || "pagevault.sid");
    res.json({ message: "Signed out successfully." });
  });
});

router.get("/me", (req, res) => {
  const csrfToken = ensureCsrfToken(req.session);
  res.json({ user: req.session.user || null, csrfToken });
});

module.exports = router;
