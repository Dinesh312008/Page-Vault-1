const express = require("express");
const { z } = require("zod");
const asyncRoute = require("../utils/asyncRoute");
const { requireAuth } = require("../middleware/auth");
const bookService = require("../services/bookService");
const openLibrary = require("../services/openLibraryService");
const recommendationService = require("../services/recommendationService");
const { isValidCourseCode, listDepartments, normalizeCourseCode } = require("../utils/courseTaxonomy");
const db = require("../db/database");

const router = express.Router();

const courseCodeSchema = z
  .string()
  .trim()
  .max(12)
  .optional()
  .nullable()
  .transform((val) => (val === "" ? null : val))
  .refine((val) => !val || isValidCourseCode(val), {
    message: "Course code must match university taxonomy (e.g., CS301, AI402, HS105).",
  })
  .transform((val) => (val ? normalizeCourseCode(val) : null));

router.get("/taxonomy", (req, res) => {
  res.json({
    pattern: "DEPT + 3-digit level (100-899), e.g. CS301",
    departments: listDepartments(),
  });
});

router.get("/recommendations", (req, res) => {
  const schema = z.object({
    q: z.string().trim().max(100).optional().default(""),
    courseCode: courseCodeSchema,
    limit: z.coerce.number().int().min(1).max(20).default(5),
  });
  const params = schema.parse(req.query);
  const userId = req.session && req.session.user ? req.session.user.id : null;
  const recommendations = recommendationService.recommendForUser(userId, {
    query: params.q,
    courseCode: params.courseCode || "",
    limit: params.limit,
  });
  res.json({ data: recommendations });
});

router.get("/", (req, res) => {
  const querySchema = z.object({
    page: z.coerce.number().int().min(1).default(1),
    limit: z.coerce.number().int().min(1).max(50).default(12),
    search: z.string().trim().max(100).optional(),
    status: z.enum(["available", "requested", "borrowed"]).optional(),
    courseCode: courseCodeSchema,
  });
  res.json(bookService.listBooks(querySchema.parse(req.query)));
});

router.get("/open-library", asyncRoute(async (req, res) => {
  const query = z.string().trim().min(2).max(100).parse(req.query.q);
  res.json({ data: await openLibrary.searchOpenLibrary(query, 12) });
}));

router.post("/", requireAuth, (req, res) => {
  const schema = z.object({
    title: z.string().trim().min(1).max(180),
    author: z.string().trim().min(1).max(120),
    isbn: z.string().trim().max(20).optional().default(""),
    courseCode: courseCodeSchema,
    description: z.string().trim().max(1000).optional().default(""),
    coverUrl: z.string().url().optional().nullable(),
  });
  const book = bookService.addBook(req.session.user.id, schema.parse(req.body));
  res.status(201).json({ book });
});

router.get("/mine", requireAuth, (req, res) => {
  const books = db.prepare("SELECT * FROM books WHERE owner_id=? ORDER BY created_at DESC").all(req.session.user.id);
  res.json({ data: books });
});

module.exports = router;
