const fs = require("node:fs");
const path = require("node:path");
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const cron = require("node-cron");
const config = require("./config/env");
const logger = require("./config/logger");
const { csrfProtection } = require("./middleware/csrf");
const { recordHttpMetric, formatPrometheusMetrics } = require("./utils/metrics");
const { getCacheStats } = require("./services/openLibraryService");
require("./db/database");

const app = express();
app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false, limit: "100kb" }));

app.use((req, res, next) => {
  req.id = require("node:crypto").randomUUID();
  res.setHeader("X-Request-Id", req.id);
  const startNs = process.hrtime.bigint();
  res.on("finish", () => {
    const durationMs = Number(process.hrtime.bigint() - startNs) / 1e6;
    const routeLabel = req.route ? `${req.baseUrl || ""}${req.route.path}` : req.path;
    recordHttpMetric(req.method, routeLabel, res.statusCode, durationMs);
  });
  next();
});

app.use(session({
  name: config.SESSION_NAME,
  secret: config.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  store: new SQLiteStore({
    db: path.basename(config.SESSION_DB_PATH),
    dir: path.dirname(path.resolve(config.SESSION_DB_PATH)),
  }),
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: config.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 8,
  },
}));

app.use(csrfProtection);
app.use("/api/auth", rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: "draft-7", legacyHeaders: false }));
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/books", require("./routes/bookRoutes"));
app.use("/api/borrow", require("./routes/borrowRoutes"));
app.use("/api/notifications", require("./routes/notificationRoutes"));

app.get("/api/health", (req, res) => res.json({ status: "ok", timestamp: new Date().toISOString() }));
app.get("/metrics", (req, res) => {
  res.setHeader("Content-Type", "text/plain; version=0.0.4; charset=utf-8");
  res.send(formatPrometheusMetrics(getCacheStats()));
});

app.use(express.static(path.join(__dirname, "../public")));
app.use((req, res) => {
  if (req.path.startsWith("/api/")) return require("./middleware/errorHandler").notFound(req, res);
  res.sendFile(path.join(__dirname, "../public/index.html"));
});

const { errorHandler } = require("./middleware/errorHandler");
app.use(errorHandler);

let reminderTask;
function startReminderJob() {
  reminderTask = cron.schedule("0 9 * * *", async () => {
    try {
      const count = require("./services/reminderService").notifyOverdue();
      logger.info("Overdue reminder job completed", { notificationsCreated: count });
    } catch (error) {
      logger.error("Overdue reminder job failed", { message: error.message, stack: error.stack });
    }
  }, { timezone: "Asia/Kolkata" });
}
if (config.NODE_ENV !== "test") startReminderJob();

if (require.main === module) {
  fs.mkdirSync(path.resolve("./logs"), { recursive: true });
  const server = app.listen(config.PORT, () => logger.info("PageVault server started", { port: config.PORT, environment: config.NODE_ENV }));
  const shutdown = (signal) => {
    logger.info("Graceful shutdown requested", { signal });
    if (reminderTask) reminderTask.stop();
    server.close(() => {
      try { require("./db/database").close(); } catch (e) { logger.error("Database close failed", { message: e.message }); }
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 10000).unref();
  };
  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
}

module.exports = app;
