const test = require("node:test");
const assert = require("node:assert/strict");

const { parseCourseCode, isValidCourseCode, normalizeCourseCode, listDepartments } = require("../src/utils/courseTaxonomy");
const { TtlCache } = require("../src/utils/apiCache");
const { ensureCsrfToken, csrfProtection } = require("../src/middleware/csrf");
const { recordHttpMetric, formatPrometheusMetrics } = require("../src/utils/metrics");

// Load rankBooks directly from recommendationService without requiring SQLite in pure unit tests
function loadPureRanker() {
  const Module = require("node:module");
  const origLoad = Module._load;
  Module._load = function (request, parent, isMain) {
    if (request === "../db/database") return {};
    return origLoad.call(this, request, parent, isMain);
  };
  try {
    return require("../src/services/recommendationService");
  } finally {
    Module._load = origLoad;
  }
}

test("courseTaxonomy validates and normalizes university course codes", () => {
  assert.equal(isValidCourseCode("cs301"), true);
  assert.equal(isValidCourseCode("AI-402"), true);
  assert.equal(normalizeCourseCode(" ml 210 "), "ML210");
  assert.deepEqual(parseCourseCode("CS301"), {
    code: "CS301",
    department: "CS",
    departmentName: "Computer Science & Engineering",
    level: 300,
    number: 301,
  });

  assert.equal(isValidCourseCode("ZZ999"), false);
  assert.equal(isValidCourseCode("CS900"), false);
  assert.equal(isValidCourseCode("INVALID"), false);
  assert.ok(listDepartments().length >= 10);
});

test("TtlCache handles hits, misses, TTL expiry, and LRU eviction", async () => {
  const cache = new TtlCache({ ttlMs: 40, maxEntries: 2 });
  cache.set("k1", [1]);
  cache.set("k2", [2]);
  assert.deepEqual(cache.get("k1"), [1]); // refreshes k1 recency
  cache.set("k3", [3]); // evicts k2

  assert.equal(cache.get("k2"), undefined);
  assert.deepEqual(cache.get("k3"), [3]);

  await new Promise((r) => setTimeout(r, 60));
  assert.equal(cache.get("k1"), undefined);
  assert.equal(cache.stats().evictions, 1);
});

test("csrfProtection enforces timing-safe token on authenticated mutations", () => {
  const session = { user: { id: 1 } };
  const token = ensureCsrfToken(session);
  assert.equal(token.length, 64);

  let statusCode = 200;
  let nextCalled = false;
  const makeRes = () => ({
    status(code) {
      statusCode = code;
      return this;
    },
    json() {
      return this;
    },
  });

  // Missing token -> 403
  csrfProtection(
    { method: "POST", path: "/api/books", session, get: () => "" },
    makeRes(),
    () => { nextCalled = true; }
  );
  assert.equal(statusCode, 403);
  assert.equal(nextCalled, false);

  // Valid token -> passes
  statusCode = 200;
  csrfProtection(
    { method: "POST", path: "/api/books", session, get: (h) => (h === "x-csrf-token" ? token : "") },
    makeRes(),
    () => { nextCalled = true; }
  );
  assert.equal(statusCode, 200);
  assert.equal(nextCalled, true);
});

test("Prometheus metrics formatter outputs valid exposition counters and histograms", () => {
  recordHttpMetric("GET", "/api/books", 200, 12.5);
  const text = formatPrometheusMetrics({ hits: 4, misses: 1, size: 3 });
  assert.ok(text.includes('pagevault_http_requests_total{method="GET",route="/api/books",status="200"}'));
  assert.ok(text.includes("pagevault_openlibrary_cache_hits_total 4"));
  assert.ok(text.includes("pagevault_http_request_duration_ms_count"));
});

test("BM25 recommendation engine ranks relevant and department-matched books higher", () => {
  const { rankBooks } = loadPureRanker();
  const books = [
    { id: 1, title: "Thermodynamics", author: "Cengel", courseCode: "ME201", description: "Heat transfer", status: "available", ownerId: 9 },
    { id: 2, title: "Deep Learning Foundations", author: "Goodfellow", courseCode: "AI402", description: "Neural networks and gradient descent", status: "available", ownerId: 9 },
    { id: 3, title: "Operating Systems", author: "Silberschatz", courseCode: "CS301", description: "Processes and memory", status: "borrowed", ownerId: 9 },
  ];

  const ranked = rankBooks(books, {
    queryText: "neural networks deep learning",
    preferredDepartments: ["AI"],
    excludeOwnerId: 1,
    limit: 5,
  });

  assert.equal(ranked.length, 2); // excludes borrowed book #3
  assert.equal(ranked[0].id, 2);
  assert.ok(ranked[0].relevanceScore > ranked[1].relevanceScore);
});
