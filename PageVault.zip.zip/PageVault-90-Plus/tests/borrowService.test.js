// Real service-level tests against an isolated temporary SQLite database.
// Run with: npm test
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");

const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "pagevault-tests-"));
process.env.NODE_ENV = "test";
process.env.SESSION_SECRET = "test-only-secret-that-is-at-least-32-characters";
process.env.DATABASE_PATH = path.join(tempDir, "test.sqlite");
process.env.SESSION_DB_PATH = path.join(tempDir, "sessions.sqlite");
process.env.LOG_LEVEL = "error";

const db = require("../src/db/database");
const borrow = require("../src/services/borrowService");

let ownerId;
let borrowerId;
let otherId;
let bookId;

function resetFixture() {
  db.exec("DELETE FROM notifications; DELETE FROM borrow_requests; DELETE FROM books; DELETE FROM users;");
  const user = db.prepare("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)");
  ownerId = Number(user.run("Owner", "owner@example.test", "test-hash").lastInsertRowid);
  borrowerId = Number(user.run("Borrower", "borrower@example.test", "test-hash").lastInsertRowid);
  otherId = Number(user.run("Other", "other@example.test", "test-hash").lastInsertRowid);
  bookId = Number(db.prepare(
    "INSERT INTO books(owner_id,title,author) VALUES(?,?,?)"
  ).run(ownerId, "Clean Code", "Robert C. Martin").lastInsertRowid);
}
function expectStatus(fn, status) {
  assert.throws(fn, error => error.status === status);
}

test.beforeEach(resetFixture);

test("a student can request an available book and owner is notified", () => {
  const result = borrow.requestBook(bookId, borrowerId);
  assert.equal(result.status, "pending");
  assert.equal(db.prepare("SELECT status FROM books WHERE id=?").get(bookId).status, "requested");
  assert.equal(db.prepare("SELECT user_id FROM notifications ORDER BY id DESC LIMIT 1").get().user_id, ownerId);
});

test("a student cannot request their own book", () => {
  expectStatus(() => borrow.requestBook(bookId, ownerId), 400);
});

test("a second request cannot reserve a book that is already requested", () => {
  borrow.requestBook(bookId, borrowerId);
  expectStatus(() => borrow.requestBook(bookId, otherId), 409);
});

test("a missing book returns a not-found error", () => {
  expectStatus(() => borrow.requestBook(999999, borrowerId), 404);
});

test("only the owner can approve and approval changes both records", () => {
  const request = borrow.requestBook(bookId, borrowerId);
  expectStatus(() => borrow.decideRequest(request.id, otherId, "approved"), 403);
  const result = borrow.decideRequest(request.id, ownerId, "approved");
  assert.equal(result.status, "approved");
  assert.equal(db.prepare("SELECT status FROM books WHERE id=?").get(bookId).status, "borrowed");
});

test("a request cannot be approved twice", () => {
  const request = borrow.requestBook(bookId, borrowerId);
  borrow.decideRequest(request.id, ownerId, "approved");
  expectStatus(() => borrow.decideRequest(request.id, ownerId, "approved"), 409);
});

test("owner can reject a request and the book becomes available", () => {
  const request = borrow.requestBook(bookId, borrowerId);
  assert.equal(borrow.decideRequest(request.id, ownerId, "rejected").status, "rejected");
  assert.equal(db.prepare("SELECT status FROM books WHERE id=?").get(bookId).status, "available");
});

test("only the borrower can return an approved book", () => {
  const request = borrow.requestBook(bookId, borrowerId);
  borrow.decideRequest(request.id, ownerId, "approved");
  expectStatus(() => borrow.returnBook(request.id, otherId), 403);
  assert.equal(borrow.returnBook(request.id, borrowerId).status, "returned");
  assert.equal(db.prepare("SELECT status FROM books WHERE id=?").get(bookId).status, "available");
});

test("a returned book cannot be returned a second time", () => {
  const request = borrow.requestBook(bookId, borrowerId);
  borrow.decideRequest(request.id, ownerId, "approved");
  borrow.returnBook(request.id, borrowerId);
  expectStatus(() => borrow.returnBook(request.id, borrowerId), 409);
});

test("unknown request IDs return not-found errors", () => {
  expectStatus(() => borrow.decideRequest(999999, ownerId, "approved"), 404);
  expectStatus(() => borrow.returnBook(999999, borrowerId), 404);
});

test.after(() => {
  db.close();
  fs.rmSync(tempDir, { recursive: true, force: true });
});
