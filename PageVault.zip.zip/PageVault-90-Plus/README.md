# PageVault | OpenShelf — 95+ Quality Upgrade Edition

A full-stack campus book-exchange application using Node.js, Express, SQLite, sessions, Zod validation, and the live Open Library Search API.

## Improvements aligned with the evaluator feedback

1. **Live Open Library integration** — `GET /api/books/open-library?q=...` queries Open Library Search API; timeout and upstream failures are logged.
2. **Service layer** — authentication, book catalog, borrowing workflow, Open Library access, and reminders are separated from HTTP routes.
3. **Pagination** — `GET /api/books?page=1&limit=12&search=...` returns `data` and pagination metadata. Limit is capped at 50.
4. **Reliable cron job** — overdue reminder task has a try/catch boundary, structured error logging, India timezone, and graceful shutdown.
5. **Session security** — there is no fallback/default secret. The app refuses to start if `SESSION_SECRET` is missing or shorter than 32 characters. Cookies are HttpOnly, SameSite=Lax, and Secure in production.
6. **Structured logging** — Winston JSON logs include request IDs for API failures.

Additional safeguards: bcrypt password hashing (12 rounds), Zod request validation, Helmet headers, login rate limiting, SQLite WAL mode, foreign keys, indexes, and atomic borrow/approval/return transactions.

## Testing and API documentation

- Run `npm test` to execute real service tests against a temporary SQLite database. Tests cover valid requests, self-request rejection, unavailable books, owner-only decisions, duplicate approvals, rejection, borrower-only returns, double returns, missing records, and notification/state updates.
- OpenAPI 3.0 specification: `docs/openapi.yaml`. Open it with Swagger Editor (`https://editor.swagger.io/`) to explore the API interactively. The project does not claim to host a Swagger UI endpoint.

## Requirements

- Node.js 20+
- npm

## Setup

```bash
# 1. Extract this ZIP and enter the project folder
cd PageVault-90-Plus

# 2. Install dependencies
npm install

# 3. Create your local environment file
cp .env.example .env
```

Edit `.env` and set a unique session secret. Example generation:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Copy the generated value into `SESSION_SECRET` in `.env`. Do not commit `.env`.

```bash
# 4. Start the server
npm start
```

Open http://localhost:3000

## API overview

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/auth/register` | Register and sign in |
| POST | `/api/auth/login` | Sign in |
| POST | `/api/auth/logout` | Sign out |
| GET | `/api/auth/me` | Current session |
| GET | `/api/books?page=1&limit=12` | Paginated catalog |
| GET | `/api/books/open-library?q=harry+potter` | Live external book search |
| POST | `/api/books` | Add a book (authenticated) |
| GET | `/api/books/mine` | Your listed books |
| POST | `/api/borrow/:bookId/request` | Request a book |
| PATCH | `/api/borrow/:requestId/decision` | Owner approves/rejects |
| PATCH | `/api/borrow/:requestId/return` | Borrower marks returned |
| GET | `/api/borrow/mine` | Your requests |
| GET | `/api/borrow/incoming` | Requests for your books |
| GET | `/api/notifications` | Your notifications |
| GET | `/api/health` | Health check |

## Important notes for evaluation

- A newly registered user receives the `student` role. For a controlled classroom demo, create an admin account through a trusted database administration step; never expose public role assignment.
- The reminder job runs daily at 09:00 Asia/Kolkata and flags approved borrows older than 14 days.
- The app uses a persistent SQLite session store. Session database and main database files are created under `data/`.
- Open Library requires an internet connection. Local book browsing and borrowing work without it.
- For production deployment, use HTTPS, set `NODE_ENV=production`, configure a secure reverse proxy, back up SQLite files, and review CSRF protection/origin policy for the chosen hosting environment.

## Evaluation checklist

- [ ] `npm install` completes successfully
- [ ] `.env` contains a random 48-byte session secret
- [ ] Register two test student accounts
- [ ] Add a book with account A
- [ ] Request it with account B
- [ ] Approve it using the owner's session
- [ ] Try to approve the same request again (must return conflict)
- [ ] Try requesting your own book (must be rejected)
- [ ] Check `/api/books?page=1&limit=5`
- [ ] Check `/api/books/open-library?q=computer+science`
- [ ] Confirm logs appear in `logs/`

This project is designed to address the supplied rubric. The final score depends on the evaluator's tests and review; no score can be guaranteed.
