const $ = (id) => document.getElementById(id);
let currentUser = null, csrfToken = null, page = 1, totalPages = 1, authMode = "login";
async function api(url, options = {}) {
  const method = (options.method || "GET").toUpperCase();
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (csrfToken && method !== "GET" && method !== "HEAD") headers["X-CSRF-Token"] = csrfToken;
  const response = await fetch(`/api${url}`, { credentials: "same-origin", headers, ...options });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || "Request failed.");
  return body;
}
function escapeHtml(value="") {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function renderBooks(books) {
  $("bookGrid").innerHTML = books.length ? books.map(book => `
    <article class="book-card">
      <div class="cover">${escapeHtml((book.title || "B").slice(0,1).toUpperCase())}</div>
      <h3>${escapeHtml(book.title)}</h3><p>by ${escapeHtml(book.author)} · shared by ${escapeHtml(book.ownerName)}${book.courseCode ? ` · ${escapeHtml(book.courseCode)}` : ""}</p>
      <div class="card-bottom"><span class="pill ${book.status === "available" ? "" : "unavailable"}">${escapeHtml(book.status)}</span>
      ${book.status === "available" && currentUser && currentUser.id !== book.ownerId ? `<button class="button button-dark" data-request="${book.id}">Request</button>` : ""}
      ${!currentUser ? `<button class="button button-outline" data-signin>Sign in</button>` : ""}
      </div></article>`).join("") : `<p class="muted">No books found. Try a different search.</p>`;
  document.querySelectorAll("[data-request]").forEach(btn => btn.addEventListener("click", async () => {
    try { await api(`/borrow/${btn.dataset.request}/request`, { method:"POST", body:"{}" }); alert("Request sent to the book owner."); loadBooks(); }
    catch(e) { alert(e.message); }
  }));
  document.querySelectorAll("[data-signin]").forEach(btn => btn.addEventListener("click", openAuth));
}
async function loadBooks() {
  $("bookGrid").innerHTML = `<p class="muted">Loading books…</p>`;
  try {
    const q = new URLSearchParams({ page, limit: 8 });
    if ($("searchInput").value.trim()) q.set("search", $("searchInput").value.trim());
    if ($("statusFilter").value) q.set("status", $("statusFilter").value);
    const result = await api(`/books?${q}`);
    totalPages = Math.max(1, result.pagination.totalPages);
    $("pageInfo").textContent = `Page ${page} of ${totalPages}`;
    $("prevPage").disabled = page <= 1; $("nextPage").disabled = page >= totalPages;
    renderBooks(result.data);
  } catch(e) { $("bookGrid").innerHTML = `<p class="muted">${escapeHtml(e.message)}</p>`; }
}
function updateAccount() {
  $("userLabel").textContent = currentUser ? currentUser.name : "Guest";
  $("authButton").textContent = currentUser ? "Sign out" : "Sign in";
}
function openAuth() { $("modal").classList.remove("hidden"); $("authMessage").textContent = ""; }
function closeAuth() { $("modal").classList.add("hidden"); }
$("authButton").addEventListener("click", async () => {
  if (!currentUser) return openAuth();
  try { await api("/auth/logout", {method:"POST"}); currentUser=null; csrfToken=null; updateAccount(); loadBooks(); }
  catch(e) { alert(e.message); }
});
$("closeModal").addEventListener("click", closeAuth);
$("toggleAuth").addEventListener("click", () => {
  authMode = authMode === "login" ? "register" : "login";
  $("authTitle").textContent = authMode === "login" ? "Sign in" : "Create account";
  $("authName").classList.toggle("hidden", authMode === "login");
  $("authName").required = authMode === "register";
  $("toggleAuth").textContent = authMode === "login" ? "Create an account instead" : "I already have an account";
});
$("authForm").addEventListener("submit", async e => {
  e.preventDefault(); $("authMessage").textContent = "Please wait…";
  const payload = { email:$("authEmail").value, password:$("authPassword").value };
  if (authMode === "register") payload.name = $("authName").value;
  try {
    const result = await api(`/auth/${authMode}`, {method:"POST", body:JSON.stringify(payload)});
    currentUser = result.user; csrfToken = result.csrfToken || csrfToken; updateAccount(); closeAuth(); loadBooks(); $("authForm").reset();
  } catch(err) { $("authMessage").textContent = err.message; }
});
$("bookForm").addEventListener("submit", async e => {
  e.preventDefault();
  if (!currentUser) { openAuth(); $("formMessage").textContent = "Sign in to share a book."; return; }
  const form = new FormData(e.currentTarget), payload = Object.fromEntries(form.entries());
  try {
    await api("/books", {method:"POST", body:JSON.stringify(payload)});
    e.currentTarget.reset(); $("formMessage").textContent = "Your book has been added to the shelf!";
    page=1; loadBooks();
  } catch(err) { $("formMessage").textContent = err.message; }
});
$("searchBtn").addEventListener("click", () => { page=1; loadBooks(); });
$("refreshBtn").addEventListener("click", () => loadBooks());
$("searchInput").addEventListener("keydown", e => { if(e.key==="Enter"){page=1;loadBooks();} });
$("statusFilter").addEventListener("change", () => {page=1;loadBooks();});
$("prevPage").addEventListener("click", () => {if(page>1){page--;loadBooks();}});
$("nextPage").addEventListener("click", () => {if(page<totalPages){page++;loadBooks();}});
(async function init() {
  try { const me = await api("/auth/me"); currentUser = me.user; csrfToken = me.csrfToken; } catch {}
  updateAccount(); loadBooks();
})();
